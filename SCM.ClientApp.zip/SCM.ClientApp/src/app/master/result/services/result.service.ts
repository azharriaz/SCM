import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/Services/apiService';

@Injectable({
  providedIn: 'root'
})
export class ResultService {
  ResourceInfo:string="studentresultsrv";
  constructor(private apiService: ApiService) { }
  public getStudentResult(rollNo:string,courseNo:string): Observable<number> {
    return this.apiService.get<number>(this.formateUrl(rollNo,courseNo)).pipe();
  }
  formateUrl(rollNo:string,courseNo:string){
    if(courseNo)
    return `${this.ResourceInfo}?rollNo=${rollNo}&courseNo=${courseNo}`;
    else return `${this.ResourceInfo}?rollNo=${rollNo}`;
  }
}
