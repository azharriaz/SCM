import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { ResultService } from '../services/result.service';
import { Router } from '@angular/router';
import { AlertService } from '../../student/services/alert-srv';

@Component({
  selector: 'app-student-result',
  templateUrl: './student-result.component.html',
  styleUrls: ['./student-result.component.scss']
})
export class StudentResultComponent implements OnInit {

  studentResultForm: FormGroup;
  constructor(private http: ResultService,private _fb: FormBuilder,
    private alertSrv:AlertService, private router: Router) {
    this.studentResultForm = this._fb.group({
      courseNo: [''],
      rollNo: ['', [Validators.required]]
     
    });
   }
  ngOnInit(): void {
  }
  GetStudentResult(rollNo:string,courseNo){
    this.http.getStudentResult(rollNo,courseNo).subscribe((data:number)=>{
      if(!data) return this.alertSrv.alertError("No record found");
      this.alertSrv.alertSuccess(courseNo?`Course GPA is ${data}`:`Entered Student's CGPA is ${data}`);
    },
    (error)=>{
      this.alertSrv.alertError("Something went wrong. Try Again later or check Roll no.");
    }
    )
  }
  onSubmit(form: NgForm) {
    if(form.invalid) return;
    this.GetStudentResult(this.RollNo.value,this.CourseNo.value);
  }
  
  get RollNo() { return this.studentResultForm.get('rollNo'); }
  get CourseNo() { return this.studentResultForm.get('courseNo'); }
}
