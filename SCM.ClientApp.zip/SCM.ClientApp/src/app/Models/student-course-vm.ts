import { Student } from './Student';
import { Course } from './Course';

export class StudentCourseVM{
    students:Student[];
    courses:Course[];
}