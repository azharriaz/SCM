export let MENU_ITEM = [
   
    {
        path: '/master/students',
        title: 'Students',
    },
    {
        path: '/master/student-course',
        title: 'Student Courses',
    },
    {
        path: '/master/student-result',
        title: 'Student Result',
    },
];
