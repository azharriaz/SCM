export class User {
   UserId: number = 0;
   Username: string;
   Password: string;
   FirstName:string;
   LastName:string;
   CreatedOn: Date;
   CreatedUserId: number;
   UpdateOn: Date;
   UpdateUserId: number;
}
