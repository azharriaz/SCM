export class StudentCourse {
    studentCourseId:number;
    studentId:number;
    studentName:string;
    rollNo:string;
    courseId:number;
    courseName:	string;
    courseNo:string;
    totalCreditHours:number;
    obtainedCreditHours:number;
    isDeleted:boolean;
    }
    