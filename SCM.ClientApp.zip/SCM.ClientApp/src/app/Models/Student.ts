export class Student {
  studentId: number ;
  name: string;
  rollNo: string;
  email: string;
  phone: string;
  address: string;
  isDeleted:boolean;
  }
  