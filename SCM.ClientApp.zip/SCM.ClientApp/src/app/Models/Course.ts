export class Course {
    courseId:number;
    name:	string;
    courseNo:string;
    creditHours:number;
    }