export class Response {
    Message:string;
    Status:string;
    Value:string;
   
}
