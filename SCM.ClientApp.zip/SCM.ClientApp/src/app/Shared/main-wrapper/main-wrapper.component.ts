import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'main-wrapper',
  templateUrl: './main-wrapper.component.html',
  styleUrls: ['./main-wrapper.component.scss']
})
export class MainWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
