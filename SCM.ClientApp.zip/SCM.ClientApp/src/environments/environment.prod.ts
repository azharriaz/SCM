export const environment = {
  production: true,
  BaseURL: "http://lifelineservice.muzzammil.net",
  //BaseURL: "http://service.drrizwangohar.com",
  
};
